import sys,json;sys.path.insert(0,'/home/claude/tools')
from router import Router
board=sys.argv[1];jobs=json.loads(sys.argv[2]);res=[]
for net,a,z,w,reg in jobs:
    r=Router(board,tuple(reg),width=w,layers=('In2.Cu',))
    r.build(r.b.FindNet(net).GetNetCode())
    out=r.route(tuple(a),'In2.Cu',tuple(z),'In2.Cu',free_a=1,free_z=1)
    res.append([net,w,out,a,z]);print(net,a,z,out and out['segments'],file=sys.stderr)
json.dump(res,open('in2_routes.json','w'))
