import re,sys
CX,CY=50.0,42.0
X0,Y0,X1,Y1=40.2,31.6,59.8,52.4
cluster={'U2','C29','C30','C31','C32','C33','C34','C35','C36','C37','C38','C39','C40','C41','R2','R3','R4','R9'}
dropnets={'H_OUT_RAW','V_OUT_RAW'}
L=open(sys.argv[1],encoding='utf-8').read().split('\n')
nets={int(m.group(1)):m.group(2) for l in L for m in [re.match(r'\s*\(net (\d+) "(.*)"\)$',l)] if m}
f=lambda v:('%.6f'%v).rstrip('0').rstrip('.')
def ang(r):
    r=(r+180)%360
    if abs(r)<1e-9 or abs(r-360)<1e-9:return None
    return r
out=[];i=0;rot_fp=0;log={'seg_rot':0,'seg_del':0,'via_rot':0,'via_del':0}
ins=lambda x,y:X0<x<X1 and Y0<y<Y1
while i<len(L):
    l=L[i]
    if l.startswith('  (footprint '):
        j=i;depth=0
        while True:
            depth+=L[j].count('(')-L[j].count(')')
            if depth==0 and j>i:break
            j+=1
        blk=L[i:j+1];txt='\n'.join(blk)
        ref=re.search(r'\(fp_text reference "([^"]+)"',txt)
        if ref and ref.group(1) in cluster:
            first=[True]
            def sub(m):
                a,b=float(m.group(1)),float(m.group(2));r=float(m.group(3)) if m.group(3) else 0.0
                if first[0]:
                    first[0]=False;a,b=2*CX-a,2*CY-b
                nr=ang(r);return f'(at {f(a)} {f(b)}' + (f' {f(nr)}' if nr is not None else '') + ')'
            txt=re.sub(r'\(at ([-\d.]+) ([-\d.]+)(?: ([-\d.]+))?\)',sub,txt);rot_fp+=1
            blk=txt.split('\n')
        out.extend(blk);i=j+1;continue
    m=re.match(r'  \(segment \(start ([-\d.]+) ([-\d.]+)\) \(end ([-\d.]+) ([-\d.]+)\)(.*\(net (\d+)\).*)$',l)
    if m:
        ax,ay,bx,by=map(float,m.group(1,2,3,4));net=nets[int(m.group(6))]
        ia,ib=ins(ax,ay),ins(bx,by)
        if (ia or ib) and (net in dropnets or ia!=ib):log['seg_del']+=1;i+=1;continue
        if ia and ib:
            l=f'  (segment (start {f(2*CX-ax)} {f(2*CY-ay)}) (end {f(2*CX-bx)} {f(2*CY-by)})'+m.group(5);log['seg_rot']+=1
        out.append(l);i+=1;continue
    m=re.match(r'  \(via \(at ([-\d.]+) ([-\d.]+)\)(.*\(net (\d+)\).*)$',l)
    if m:
        x,y=float(m.group(1)),float(m.group(2));net=nets[int(m.group(4))]
        if ins(x,y):
            if net in dropnets:log['via_del']+=1;i+=1;continue
            l=f'  (via (at {f(2*CX-x)} {f(2*CY-y)})'+m.group(3);log['via_rot']+=1
        out.append(l);i+=1;continue
    out.append(l);i+=1
open(sys.argv[2],'w',encoding='utf-8').write('\n'.join(out))
print('footprints rotated',rot_fp,log)
