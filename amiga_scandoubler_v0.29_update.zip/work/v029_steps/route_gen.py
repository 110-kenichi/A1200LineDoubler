import sys,json;sys.path.insert(0,'/home/claude/tools')
from router import Router
board,net,a,la,z,lz,reg,blocks,out=sys.argv[1:10]
r=Router(board,tuple(json.loads(reg)))
for g,ls in json.loads(blocks):r.block(tuple([g[0]]+[tuple(x) if isinstance(x,list) else x for x in g[1:]]),set(ls) if ls!="all" else "all")
r.build(r.b.FindNet(net).GetNetCode())
res=r.route(tuple(json.loads(a)),la,tuple(json.loads(z)),lz,via_cost=30,free_a=2,free_z=2)
json.dump([[net,0.15,res]],open(out,'w'));print(net,res and res['segments'],res and res['vias'])
