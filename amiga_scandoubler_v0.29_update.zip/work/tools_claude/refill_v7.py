# Refill In1 GND zone with KiCad10 and transplant filled polygon into KiCad7-format file
import re,subprocess,sys
src,dst=sys.argv[1],sys.argv[2]
tmp='/tmp/_fill.kicad_pcb'
subprocess.run(['/opt/kicad/squashfs-root/bin/python3','-c',f"import pcbnew as p;b=p.LoadBoard('{src}');p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard('{tmp}',b)"],capture_output=True)
new=open(tmp).read()
blocks=re.findall(r'\(filled_polygon\s*\(layer "In1\.Cu"\)\s*\(pts(.*?)\)\s*\)',new,re.S)
old=open(src).read()
pat=r'    \(filled_polygon\n      \(layer "In1\.Cu"\)\n      \(pts\n(?:        \(xy [^\n]*\)\n)+      \)\n    \)'
olds=list(re.finditer(pat,old))
assert len(olds)>=1 and len(blocks)>=1,(len(olds),len(blocks))
txt=''.join('    (filled_polygon\n      (layer "In1.Cu")\n      (pts\n'+''.join('        %s\n'%x for x in re.findall(r'\(xy [-\d.]+ [-\d.]+\)',b))+'      )\n    )\n' for b in blocks).rstrip('\n')
out=old[:olds[0].start()]+txt+old[olds[-1].end():]
open(dst,'w').write(out);print('filled polygons',len(olds),'->',len(blocks))
